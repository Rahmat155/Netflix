const admin = require('firebase-admin');

const rawCredentials = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
if (!rawCredentials) {
  throw new Error('Secret FIREBASE_SERVICE_ACCOUNT_JSON belum diatur di GitHub.');
}

let serviceAccount;
try {
  serviceAccount = JSON.parse(rawCredentials);
} catch {
  throw new Error('Secret FIREBASE_SERVICE_ACCOUNT_JSON bukan JSON yang valid.');
}

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  projectId: 'netflix-monitoring'
});

const db = admin.firestore();
const messaging = admin.messaging();
const TIME_ZONE = 'Asia/Jakarta';
const REMINDER_DAYS = new Map([[3, 'H-3'], [1, 'H-1'], [0, 'H-0']]);

function jakartaDateKey(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: TIME_ZONE,
    year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function dayNumber(dateKey) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey || '')) return NaN;
  const [year, month, day] = dateKey.split('-').map(Number);
  return Math.floor(Date.UTC(year, month - 1, day) / 86400000);
}

async function main() {
  const today = jakartaDateKey();
  const orders = await db.collection('monitoringOrders').get();
  let sent = 0;
  let skipped = 0;
  let failed = 0;

  for (const orderDoc of orders.docs) {
    const order = orderDoc.data();
    const expiryDate = order.expiryDate;
    const uid = order.uid;
    const remaining = dayNumber(expiryDate) - dayNumber(today);
    const reminderCode = REMINDER_DAYS.get(remaining);

    if (!reminderCode || !uid || !order.email) {
      skipped++;
      continue;
    }

    const alreadySent = order.remindersSent && order.remindersSent[reminderCode] === expiryDate;
    if (alreadySent) {
      skipped++;
      continue;
    }

    const tokenDoc = await db.collection('pushTokens').doc(uid).get();
    const token = tokenDoc.exists && tokenDoc.data().token;
    if (!token) {
      console.log(`Lewati ${orderDoc.id}: token notifikasi belum tersedia.`);
      skipped++;
      continue;
    }

    const title = reminderCode === 'H-0'
      ? 'Paket Netflix habis hari ini'
      : `Pengingat masa aktif Netflix ${reminderCode}`;
    const body = reminderCode === 'H-0'
      ? `Paket untuk ${order.email} berakhir hari ini. Hubungi admin jika ingin memperpanjang.`
      : `Paket untuk ${order.email} akan berakhir ${remaining} hari lagi. Segera periksa masa aktifnya.`;

    try {
      await messaging.send({
        token,
        notification: { title, body },
        data: {
          orderId: orderDoc.id,
          reminder: reminderCode,
          expiryDate,
          url: 'https://rahmat155.github.io/Netflix/'
        },
        webpush: {
          notification: {
            title,
            body,
            icon: 'https://rahmat155.github.io/Netflix/favicon.ico',
            tag: `razh-${orderDoc.id}-${reminderCode}`
          },
          fcmOptions: { link: 'https://rahmat155.github.io/Netflix/' }
        }
      });

      await orderDoc.ref.update({
        [`remindersSent.${reminderCode}`]: expiryDate,
        lastReminderAt: admin.firestore.FieldValue.serverTimestamp()
      });
      sent++;
      console.log(`Terkirim ${reminderCode}: ${orderDoc.id}`);
    } catch (error) {
      failed++;
      console.error(`Gagal ${reminderCode} untuk ${orderDoc.id}:`, error.message);
      const invalidToken = [
        'messaging/registration-token-not-registered',
        'messaging/invalid-registration-token'
      ].includes(error.code);
      if (invalidToken) {
        await tokenDoc.ref.delete().catch(() => {});
      }
    }
  }

  console.log(`Selesai. Terkirim: ${sent}; dilewati: ${skipped}; gagal: ${failed}; tanggal WIB: ${today}`);
  if (failed > 0) process.exitCode = 1;
}

main().catch(error => {
  console.error('Proses pengingat gagal:', error);
  process.exitCode = 1;
});
